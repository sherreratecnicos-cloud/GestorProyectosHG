import SwiftUI

@main
struct GestorProyectosHGApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
